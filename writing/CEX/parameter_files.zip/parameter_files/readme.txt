Manifest:

AMOEBA-BIO-2018_residues.xml contains AMOEBA simulation parameters
residues_mod.xml contains residue entries for OpenMM

ch_top_water_ions.rtf contains topology segments from the CHARMM36 toppar_water_ions.str file
ch_par_water_ions.prm contains parameter segments from the CHARMM36 toppar_water_ions.str file
